import React from 'react'

export default function Resorts() {
  return (
    <div>Resorts</div>
  )
}
