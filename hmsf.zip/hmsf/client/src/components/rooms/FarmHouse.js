import React from 'react'

export default function FarmHouse() {
  return (
    <div>FarmHouse</div>
  )
}
