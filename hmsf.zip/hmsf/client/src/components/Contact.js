import React from 'react'

export default function Contact() {
  return (
    <div>This is contact page</div>
  )
}
