import React from 'react'

export default function Home() {
  return (
    <div>This is home page</div>
  )
}
